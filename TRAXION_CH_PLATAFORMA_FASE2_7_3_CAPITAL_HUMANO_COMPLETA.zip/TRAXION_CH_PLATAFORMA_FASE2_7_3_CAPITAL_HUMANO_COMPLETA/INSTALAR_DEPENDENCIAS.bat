@echo off
title Instalar dependencias - Plataforma CH
cd /d %~dp0
python -m pip install --upgrade pip
pip install -r requirements.txt
pause
