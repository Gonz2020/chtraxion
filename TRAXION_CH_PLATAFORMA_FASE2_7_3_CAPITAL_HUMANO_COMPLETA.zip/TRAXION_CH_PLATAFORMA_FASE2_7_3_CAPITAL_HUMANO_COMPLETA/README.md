# Plataforma Integral de Capital Humano Traxión - Fase 2.6

Versión con mejoras de IA, reportes ejecutivos y administración básica de catálogos.

## Ejecutar

```powershell
pip install -r requirements.txt
python app.py
```

Abrir:

http://127.0.0.1:5000

## Incluye

- Dashboard ejecutivo tipo Power BI.
- Menú lateral estilo SAP.
- Candidatos y expediente operativo.
- Entrevista 1 y Entrevista 2.
- Hoja de Ruta digital.
- Oferta laboral.
- Servicio médico.
- Evaluación técnica.
- Documentación.
- Inducción.
- Seguimiento por SLA.
- Agenda de entrevistas.
- Headcount y cobertura.
- Reportes exportables.
- Catálogos editables.
- IA Capital Humano: análisis de candidato y generador de preguntas.
