@echo off
title Plataforma Integral Capital Humano Traxion
cd /d %~dp0
python app.py
pause
